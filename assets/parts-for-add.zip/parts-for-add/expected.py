import random

import matplotlib.pyplot as plt
import numpy as np

elements = 10**6

weights = [50, 20, 10, 20, 30, 40]
values = [-100, -500, 500, 400, 300, 200]
weight_total = sum(weights)

expected_value = 0
for i in range(len(values)):
    expected_value += ((weights[i] / weight_total) * values[i])

x = np.linspace(1, elements, elements)
value = random.choices(population=values, weights=weights, k=elements)
y = np.cumsum(value)

plt.rc('lines', linewidth=2.5)
fig, ax = plt.subplots()
ax.set_title('Valor Esperado')
ax.grid(True)
ax.set_xscale('log')
ax.set_yscale('symlog')

line1, = ax.plot(x, expected_value * x, dashes=[6, 2], label='valor esperado')
line2, = ax.plot(x, y, label='valor gerado')

ax.legend(handlelength=4)
plt.show()

plt.show()
