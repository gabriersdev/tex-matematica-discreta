A = float(input("Qual a probablidade de A: \n"))
B = float(input("Qual a probablidade de B: \n"))
AB = float(input("Qual a probablidade de A|B: \n"))

print("A possibilidade de B dado A é: ", AB * B / A, "")
